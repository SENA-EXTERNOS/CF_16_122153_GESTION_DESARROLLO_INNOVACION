function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6OY8Df5QdpE":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

